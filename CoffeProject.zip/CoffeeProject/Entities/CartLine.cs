﻿using System;
namespace CoffeeProject.Entities
{
	public class CartLine
	{
        public Coffee Coffee { get; set; }
        public int Quantity { get; set; }
    }
}

