﻿using System;
using CoffeeProject.Entities;

namespace CoffeeProject.Models
{
    public class CartSummaryViewModel
    {
        public Cart Cart { get; set; }
    }
}

