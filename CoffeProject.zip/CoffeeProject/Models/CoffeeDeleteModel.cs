﻿using System;
namespace CoffeeProject.Models
{
	public class CoffeeDeleteModel
	{
		public int Id { get; set; }
	}
}

