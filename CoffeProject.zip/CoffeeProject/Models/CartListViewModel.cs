﻿using System;
using CoffeeProject.Entities;

namespace CoffeeProject.Models
{
	public class CartListViewModel
	{
		public Cart Cart { get; internal set; }
	}
}

